const myHeading = document.querySelector('h1');
myHeading.textContent = 'Hello World!';

let name = prompt('enter your name')